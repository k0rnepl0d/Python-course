def find_(list0, list1, list_result):
    for i_list_0 in list0:
        for i_list_1 in list1:
            if i_list_0 != i_list_1:
                list_result.append(i_list_1)
    print(list_result)
    print(len(list_result))


def main():
    list_0 = ['A', 'b', 'G', 'H', '6', 's', 'L', 'v', '34', 'ssf', 'python', 'java', 'JS', 'stack', 'TS']
    list_1 = ['python', 'stack', 'b', 'G', 'H', '6', 's', 'SSH', 'pascalABC', 'VS Code', 'data', 'venv', 'k', 'h', 'm', 'GG', 'caHDCVv', '.NET', 'C#', 'Run']
    list_result = []

    find_(list0=list_0, list1=list_1, list_result=list_result)


if __name__ == '__main__':
    main()
