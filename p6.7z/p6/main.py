def find_(string):
    list_ = string.split(' ')
    sum_ = 0

    for i in list_:
        data = i
        data = data.find('А')

        if data == -1:
            print(f'{i} => False')
        else:
            print(f'{i} => True')
            sum_ += 1

    print(sum_)


def main():
    while True:
        string = str(input('Input => '))
        find_(string=string)


if __name__ == '__main__':
    main()
