def _list_(list_):
    print(list_[0], list_[-1])


def main():
    list_ = ['C++', 'TypeScript', 'C', 'C#', 'Python', 'SQL', 'Rust']
    _list_(list_)


if __name__ == '__main__':
    main()