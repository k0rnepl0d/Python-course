def string(str_):
    print(str_[2], str_[4], str_[4:7])
    print(str_[-7], str_[-5], str_[-5:-2])


def main():
    str_ = '123456789'
    string(str_)


if __name__ == '__main__':
    main()
