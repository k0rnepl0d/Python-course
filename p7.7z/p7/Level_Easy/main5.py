def sum_range(start, end):
    sum_ = 0
    for i in range(start, end):
        sum_ += i
    sum_ += end
    print(sum_)


def main():
    start = int(input('Start => '))
    end = int(input('End => '))
    buffer = None

    if start > end:
        buffer = end
        end = start
        start = buffer

    sum_range(start, end)


if __name__ == '__main__':
    main()
