def string(str_):
    print(str_[-1] + str_[-2] + str_[-3])


def main():
    str_ = 'кот'
    string(str_)


if __name__ == '__main__':
    main()