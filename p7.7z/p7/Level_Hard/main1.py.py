from datetime import datetime
from time import sleep


def time_now():
    print('Сейчас такое время: ', datetime.now())
    # sleep(1)
    # print('Прошла секунда: ', datetime.now())


def main():
    time_now()


if __name__ == '__main__':
    main()
