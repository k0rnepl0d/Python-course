from math import sqrt


def S_and_P(kat_1, kat_2):
    s = (kat_1 * kat_2) / 2
    print(s)
    p = kat_1 + kat_2 + (sqrt(kat_1 ** 2 + kat_2 ** 2))
    print(p)


def main():
    kat_1 = int(input('Катет 1 => '))
    kat_2 = int(input('Катет 2 => '))

    S_and_P(kat_1, kat_2)


if __name__ == '__main__':
    main()
