message = 'Hello'

for c in message:
    print(c)
else:
    print(f'Последний символ: {c}. Цикл завершен')
print('Работа программы завершена')


for c1 in 'ab':
    for c2 in 'ba':
        print(f'{c1}{c2}')



