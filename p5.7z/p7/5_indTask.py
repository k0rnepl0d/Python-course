# 1. Написать программу, которая будет складывать, вычитать, умножать или делить два числа. +
# 2. Числа и знак операции вводятся пользователем. +
# 3. После выполнения вычисления программа не должна завершаться, а должна запрашивать новые данные для вычислений. +
# 4. Завершение программы должно выполняться при вводе символа ‘0’ в качестве знака операции. +
# 5. Если пользователь вводит неверный знак (не ‘0’, ‘+’, ‘-‘, ‘*’, ‘/’), то программа должна сообщать ему об ошибке и снова запрашивать знак операции. +
# 6. Также сообщать пользователю о невозможности деления на ноль, если он ввел 0 в качестве делителя. +


def culc(a, b, operator):
    if operator == '+':
        print(f'{a} {operator} {b} = {a + b}')

    elif operator == '-':
        print(f'{a} {operator} {b} = {a - b}')

    elif operator == '*':
        print(f'{a} {operator} {b} = {a * b}')

    elif operator == '/':
        print(f'{a} {operator} {b} = {a / b}')


def main():
    while True:
        a = int(input('a => '))
        b = int(input('b => '))
        operator = input('Operator => ')

        if operator == '0':
            print('Error (operator = 0)!')

        if (operator == 0 or operator == '/') and b == 0:
            print('Error (zero or operator)!')

        elif operator == '+' or '-' or '/' or '*':
            culc(a, b, operator)

        else:
            print('Error (check operator)!')


if __name__ == '__main__':
    main()
