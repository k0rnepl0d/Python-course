def culc(number):
    lim = len(number)
    a = int
    sum = 0
    for i in range(0, lim):
        a = int(number[i])
        if (a % 2) == 0:
            sum += a
    print(sum)


def main():
    number = input('Number => ')
    culc(number)


if __name__ == '__main__':
    main()
