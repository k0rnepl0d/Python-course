def culc(a, b, step):
    while True:
        if a <= b:
            print(a)
            a += step
        else:
            break


def main():
    a = int(input('Number => '))
    b = int(input('Number => '))
    step = int(input('Number (step) => '))
    culc(a, b, step)


if __name__ == '__main__':
    main()
