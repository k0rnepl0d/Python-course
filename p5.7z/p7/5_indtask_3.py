def culc(number):
    lim = len(number)
    a = int
    sum = 0
    comp = 1
    for i in range(0, lim):
        a = int(number[i])
        sum += a
        comp = comp * a
    print(sum)
    print(comp)


def main():
    number = input('Number => ')
    culc(number)


if __name__ == '__main__':
    main()
