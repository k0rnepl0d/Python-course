def say_hello():
    print("Hello")


say_hello()


def say_hello(name):
    print(f"Ivan, {name}!")


say_hello("Ivan")


def print_person(name, age):
    print(f"Name: {name}")
    print(f'Age: {age}')


print_person("Tom", 37)


def say_hello(name="Tom"):
    print(f"Name: {name}")


say_hello()
say_hello("Bob")


def print_person(name, age=18):
    print(f'Name: {name} Age: {age}')


print_person("Bob")
print_person("Tom", 37)

numbers = int


def sum(*number):
    result = 0
    for n in numbers:
        result += n
    print(f"sum = {result}")


sum(1, 2, 3, 4, 5)
sum(3, 4, 5, 6)
