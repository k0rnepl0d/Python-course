def task_1(number):
    while number < 5:
        print(f'number = {number}')
        number += 1
    print('Работа программы завершена')


def task_2(number):
    while number < 5:
        print(f'number = {number}')
        number += 1
    else:
        print(f'number = {number}. Работа цикла завершина')
    print('Работа программы завершина')


def task_3():
    i = 1
    j = 1
    while i < 10:
        while j < 10:
            print(i * j, end='\t')
            j += 1
        print('\n')
        j = 1
        i += 1


def task_4():
    number = 0
    while number < 5:
        number += 1
        if number == 3:
            break
        print(f'number = {number}')


def main():
    number = 1
    task_1(number=number)
    task_2(number=number)
    task_3()
    task_4()


if __name__ == '__main__':
    main()
