import math as mt
from time import sleep as sl


def task(a, b, h):
    x = a
    while True:
        x = x + h

        if x > b:
            print('x > b!')
            break

        else:
            y = ((x ** mt.sin(mt.pi / 4)) / (1 - 2 * x * mt.cos(mt.pi / 4) + x ** 2))
            print(y)

        sl(0.25)


def main():
    a = -0.5
    b = 2.5
    h = 0.2

    task(a=a, b=b, h=h)


if __name__ == '__main__':
    main()
