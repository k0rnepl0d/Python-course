import math as mt
from time import sleep as sl


def task(a, b, h):
    # y = (mt.e ** x ** mt.cos(mt.pi / 4)) * mt.cos(x * mt.cos(mt.pi / 4))
    s = ((mt.cos(k * mt.pi / 4)) / (mt.factorial(k)))
    sum = sum + s


def main():
    a = int(input('a => '))
    b = int(input('b => '))
    h = int(input('h => '))
    # n = int(input('n => '))

    list_ = [
        a, b, h
    ]

    for i in list_:
        if i == 0:
            print('Одно из чисел равно нулю!')
            break
        else:
            continue

    task(a=a, b=b, h=h, n=n)


if __name__ == '__main__':
    main()
